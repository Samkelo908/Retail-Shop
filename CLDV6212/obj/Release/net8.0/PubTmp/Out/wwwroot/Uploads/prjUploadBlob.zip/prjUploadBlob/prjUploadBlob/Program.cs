﻿using Azure.Storage.Blobs;

namespace prjUploadBlob
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            var files = GetFiles("C:\\upload");

            if (!files.Any()) 
            {
                Console.WriteLine("Nothing to process");
                return;
            }
            await uploadFilesAsync(files, "DefaultEndpointsProtocol=https;AccountName=smaswana;AccountKey=7aJ5bZD/mnrRWXw4B3ax/pz9pFan1mYzg4/DbAhq7YSrl4/EPRi6MJ1R4UFcfGY6DGvRBF8s/gjX+AStfQqz6w==;EndpointSuffix=core.windows.net", "imagefolder");
        }
        static IEnumerable<FileInfo> GetFiles(string sourceFolder)
        => new DirectoryInfo(sourceFolder)
            .GetFiles()
            .Where(f => !f.Attributes.HasFlag(FileAttributes.Hidden));
        // Asynchronous method to upload files to Azure Blob Strong

        static async Task uploadFilesAsync(IEnumerable<FileInfo> files,
            string connectionString,
            string container)
        {
            //Create a BlobContainerClient to interact with the specified container


            var containerClient = new BlobContainerClient(connectionString, container);

            Console.WriteLine("Uploading files to bulb storage");

            //Iterate through each file and upload it
            foreach (var file in files)
            {
                try
                {
                    //Create a blobClient for the file
                    var blobClient = containerClient.GetBlobClient(file.Name);
                    using (var fileStream = File.OpenRead(file.FullName))
                    {
                        await blobClient.UploadAsync(fileStream);
                    }
                    Console.WriteLine($"{file.Name} uploaded");

                    File.Delete(file.FullName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
        }
    }
}
