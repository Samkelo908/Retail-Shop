﻿using Azure.Storage.Blobs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DialogUpload
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void bynUpload_Click(object sender, EventArgs e)
        {
            var File = SelectFile();
            if (File == null)
            {
                Console.WriteLine("No file was selected");
                return;
            }
            await UploadFileAsync(File, "DefaultEndpointsProtocol=https;AccountName=smaswana;AccountKey=7aJ5bZD/mnrRWXw4B3ax/pz9pFan1mYzg4/DbAhq7YSrl4/EPRi6MJ1R4UFcfGY6DGvRBF8s/gjX+AStfQqz6w==;EndpointSuffix=core.windows.net", "imagefolder");
        }
        public static FileInfo SelectFile()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                return new FileInfo(ofd.FileName);
            }
            return null;
        }

        public async Task UploadFileAsync(FileInfo file,string connectionString, string container)
        {
            var containerClient = new BlobContainerClient(connectionString, container);

            Console.WriteLine("Uploading file to the blob storage");

            try
            {
                var blobClient = containerClient.GetBlobClient(file.Name);
                using (var fileeStream = File.OpenRead(file.FullName))
                {
                    await blobClient.UploadAsync(fileeStream);
                }

                Console.WriteLine($"{file.Name} Uploaded");

                File.Delete(file.FullName);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        private List<string> imageUrl = new List<string>();
        private int currentIndex = 0;

        private void DisplayImage(string imageUrl)
        {
            if (pdOutput != null)
            {
                pdOutput.Load(imageUrl);
            }

        }
        private async Task FetchImageUrlsAsync(string connectionString, string container)
        {
            var ContainerClient = new BlobContainerClient(connectionString, container);

            await foreach (var blobItem in ContainerClient.GetBlobsAsync())
            {
                var blobClient = ContainerClient.GetBlobClient(blobItem.Name);
                imageUrl.Add(blobClient.Uri.ToString());
            }
        }

        private async void pdOutput_Click(object sender, EventArgs e)
        {
            await UploadFileAsync("DefaultEndpointsProtocol=https;AccountName=smaswana;AccountKey=7aJ5bZD/mnrRWXw4B3ax/pz9pFan1mYzg4/DbAhq7YSrl4/EPRi6MJ1R4UFcfGY6DGvRBF8s/gjX+AStfQqz6w==;EndpointSuffix=core.windows.net");
            if (imageUrl.Count > 0)
            {
                DisplayImage(imageUrl[currentIndex]);
                currentIndex++;
            }
        }
    }
}
